PDF Conversion Summary
======================
Original format: PDF
Output format: JPG
Total pages: 2
Conversion method: ImageMagick
Resolution: 300 DPI
Created: 2025-06-03 11:47:23

Files in this archive:
convertre_683ee0ba20237_1748951242_f3d16461-page-000.jpg
convertre_683ee0ba20237_1748951242_f3d16461-page-001.jpg
